const express = require('express');
const app = express();
const path = require('path');
const UserModel = require('./models/User');
const PostModel = require('./models/Post');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const post = require('./models/Post');
const upload = require('./config/multerconfig');



//middleware
app.use(express.json());
app.use(express.urlencoded({ extended:true }));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname,'public')));
app.use(cookieParser());


// disk storage



//routes  

app.get('/', (req, res) => {
   res.render('index');


})
app.post('/login', async (req, res) => {
  let {password, email} =req.body;

  let user = await UserModel.findOne({email});
  if(!user) {
    return res.status(400).json({message: 'Something went wrong'});
  }
  let token = jwt.sign({email: email, userid: user._id}, 'secret');
      res.cookie("token", token);
  
  let match= await bcrypt.compare(password, user.password, function(err, match) {
    if(match){
      res.redirect('/profile')
    }
    else{
      return res.status(400).json({message: 'something went wrong'});
    }
  });
    


})
app.get('/login', (req, res) => {
   res.render('login');


})

app.get('/profile', isLogedIn, async (req, res) => {
    let user = await UserModel.findOne({ email: req.user.email}).populate('posts');
    
     
      res.render('profile', {user: user});
})

// profile picturee route

app.get('/profile/upload', isLogedIn, async (req, res) => {
  
  
   
    res.render('profileupload');
})

app.post('/profile/upload', upload.single('image'), isLogedIn, async (req, res) => {
let user = await UserModel.findOne({email: req.user.email})
user.profilepic =req.file.filename

await user.save()

res.redirect('/profile');
  
   
  
})
// like route 

app.get('/like/:id', isLogedIn, async (req, res) => {
  let post = await PostModel.findOne({ _id: req.params.id}).populate('user');

  if (post.likes.indexOf(req.user.userid)=== -1){

    post.likes.push(req.user.userid)
  }
  else{
    post.likes.splice(post.likes.indexOf(req.user.userid), 1)
  }
  await post.save();
   
    res.redirect('/profile');
})

// edit route 

app.get('/edit/:id', isLogedIn, async (req, res) => {
  let post = await PostModel.findOne({_id: req.params.id}).populate('user');
 res.render('edit', {post});

})


app.post('/update/:id', isLogedIn, async (req, res) => {
  let post = await PostModel.findOneAndUpdate({_id: req.params.id},{content: req.body.content});
 res.redirect('/profile');

})


// post route
app.post('/post', isLogedIn, async (req, res) => {
  let user = await UserModel.findOne({ email: req.user.email});
  let {content} = req.body;

  let post = await PostModel.create({
    user:user._id,
    content
  })

  user.posts.push(post._id);
  await user.save();
  res.redirect('/profile');
  

})
// upload route 







//logout route
app.get('/logout', (req, res) => {
  res.clearCookie('token');
  res.redirect('/login');
 
})

//register routes

app.post('/register', async (req, res) => {
   let {username, password, email,name,age} =req.body;

  let user = await UserModel.findOne({email});
  if(user) {
    return res.status(400).json({message: 'Email already exists'});
  }
  
  bcrypt.genSalt(10,(err,salt) =>{
    bcrypt.hash(password, salt, async (err,hash)=>{
      let user = await UserModel.create({
            username,
            password: hash,
            email,
            name,
            age
        })
       let token = jwt.sign({email: email, userid: user._id}, 'secret');
        res.cookie("token", token);
        res.send("done registered");
    })
  })

})

//middleware to check if user is logged in
function isLogedIn(req, res, next) {
  const token = req.cookies.token;
  if (!token) {
    return res.redirect('/login');
  }

  try {
    const data = jwt.verify(token, 'secret');
    req.user = data;
    next();
  } catch (err) {
    return res.status(403).send("Invalid or expired token");
  }
}

//delete route
app.post('/delete/:id', isLogedIn, async (req, res) => {
  try {
    let id = req.params.id;

    // Delete the post by ID
    await PostModel.findByIdAndDelete(id);

    // Redirect to the profile page after deletion
    res.redirect('/profile');
  } catch (err) {
    console.error("Error deleting post:", err);
    res.status(500).send("An error occurred while deleting the post");
  }
});


app.listen(3000);

